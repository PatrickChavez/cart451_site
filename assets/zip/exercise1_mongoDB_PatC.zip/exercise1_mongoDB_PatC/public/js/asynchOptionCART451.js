/*
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function
 //asynch / await -> available in es8
 //return promises just like before
 //USEs promises behind the scenes
 //looks LIKE synchronous code ... no need for .then() - 
 //you though can ONLY await INSIDE asynch functions...

*/
//window.onload = function () {
    const buttonCallJ = document.querySelector("#callbackJ");
    const responseJ = document.querySelector("#responseJ");
    
    buttonCallJ.addEventListener("click", async function () {
      console.log("clicked");
      let userStr = document.querySelector("#user-string-J").value;
      let res = await checkAuth_A(userStr);
      let finalRes = await changeString_A(res);
      console.log(finalRes);

}); //button

function changeString_A(fruitString) {
  //console.log(userString);
  setTimeout(() => {
    let userFruitwithstars = fruitString.split("").join("*");
    console.log("time-out two-a complete " + fruitString);
    return userFruit;
  }, 5000); // let 5 secs go past then send back
}

