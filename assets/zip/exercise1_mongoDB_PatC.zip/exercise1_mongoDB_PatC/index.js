// Code From Class 4-5
const express = require("express");
const portNumber = 4200;
const app = express(); //make an instance of express
const server = require("http").createServer(app);
require("dotenv").config();

// create a server (using the Express framework object)
app.use(express.static(__dirname + "/public"));




app.use(express.json()); // support json encoded bodies
app.use(express.urlencoded({ extended: true })); // support encoded bodies


  
app.use("/client", clientRoute);
const mongo_connection_url = process.env.MONGO_DB_URI;

const {MongoClient} = require("mongodb"); // reference to library

const client = new MongoClient(mongo_connection_url,{}); // instance of client
async function run(){
    try {
    client.connect().then(async function(){

    
    await client.db("admin").command({ping:1});
    console.log("Success!");

    let chatbot_db = await client.db("KREESH_RAJANI_CHATBOT");
    let chatbotCollection = await chatbot_db.listCollections().toArray();
    console.log(chatbotCollection[0]);

    let listConversations = await chatbot_db.collection("conversation");

    // // Query 1
    // let result = await listConversations.findOne({"question":"hi, how are you doing?"});
    // console.log(result);

    // Query 2
    // let result2 = await listConversations.findOne({"question":"how is the weather?"});
    // console.log(result2);

    // Query 3
    // let result3 = await listConversations.findOne({"question":"i enjoy drawing and painting."});
    // console.log(result3);

    // Query 4
    // let result4 = await listConversations.findOne({"question":"you look really nice today. "});
    // console.log(result4);

    // Query 5
    let result5 = await listConversations.findOne({"question":"that was an odd change of subject."});
    console.log(result5);

    

    let getSearchCrit = async function (req, res) {
      console.log(req.query);
      let result6 = await listConversations.findOne({"question": req.query.question});
      console.log(result6);
      res.send(result6.answer);
    }
    //3:: receiving serach criteria from the client
  app.use("/sendSearch", getSearchCrit);
})
    }
    catch(error) {
        console.log(error);
    }
    finally {
        await client.close();
    }
}

run();

// make server listen for incoming messages
server.listen(portNumber, function () {
    console.log("listening on port:: " + portNumber);
    console.log(process.env.MONGO_DB_URI);
  });
  
  //default route
  app.get("/", function (req, res) {
    res.send("<h1>Hello world</h1>");
  });
  
  function clientRoute(req, res, next) {
    res.sendFile(__dirname + "/public/client.html");
  }
