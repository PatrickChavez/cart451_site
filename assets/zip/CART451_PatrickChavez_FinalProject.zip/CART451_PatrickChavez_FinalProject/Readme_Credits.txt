PRESENTED BY:

Patrick C

TOOLS:

ChatGPT

Photoshop

Piskel

Pixel Studio 

app.monopro.org

CODE:

Harlowe Audio Library (HAL), by Chapel
 
DigitalExposureTV

MudkipzLover

TheMadExile

W3Schools


MUSIC:

YouFulca

H/Mix

Maou Damashii


THANKS FOR PLAYING