PRESENTED BY:

Patrick C

BRAINSTORMING:

ChatGPT

CODE:

Harlowe Audio Library (HAL), by Chapel
 
DigitalExposureTV

MudkipzLover

TheMadExile

W3Schools


MUSIC:

YouFulca

H/Mix

Maou Damashii


THANKS FOR PLAYING